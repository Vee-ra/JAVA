/***************************************************
 **************** Type casting ***************
 ***********************************************/   
public class First { 
	public static void main(String args[]){
		
		byte b; //1byte
		int n = 100000; //4bytes
		b = (byte)n; //explicit type conversion
		System.out.println(b); 
		double d;
	}

}
