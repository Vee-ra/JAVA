
public class IfDemo2 {

	public static void main(String[] args) {
			//conditional operator
		int a=45,b=60;
		int max;

		
		max = (a>b) ? a : b;
		
		System.out.println(max);
	}

}
