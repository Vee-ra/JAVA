/*package OOP;

class Box{
	
	int length; //instance variables
	int breadth;
	int height;

	Box(int l,int b, int h){ //constructor
		length = l;
		breadth = b;
		height = h;
	}
	
	void setDim(int l,int b, int h){  
		length = l;
		breadth = b;
		height = h;
	}
	
	int volume(){
		return length*breadth*height;
	}
}
public class ConstructorOverloading {

	public static void main(String[] args) {
		Box blackBox;
		blackBox=new Box(5,4,3);
		
		blackBox.setDim(6,4,3);
		System.out.println("vol of black box is " + blackBox.volume());  //invoke

		
		Box woodBox = new Box(30,24,25);
	
		System.out.println("vol of wood box is " + woodBox.volume() ); 	
		
		woodBox.setDim(56,45,23);
	

	}

}
*/






