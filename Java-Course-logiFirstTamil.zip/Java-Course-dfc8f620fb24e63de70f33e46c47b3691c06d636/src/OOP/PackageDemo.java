package OOP;
import static java.lang.Math.*; //static import  SE 5.0

public class PackageDemo {

	public static void main(String[] args) {
		System.out.println(sqrt(3));

	}

}
