package OOP;

public class StackDemo {

	public static void main(String args[]) {
		Stack s1 = new Stack();
		
		s1.push(5);
		s1.push(6);
		s1.push(8);
		
		
		System.out.println(s1.pop());
		
		Stack s2 = new Stack();

	}
}


