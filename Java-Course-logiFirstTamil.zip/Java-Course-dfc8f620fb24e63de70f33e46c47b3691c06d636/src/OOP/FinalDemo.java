package OOP;
//final

class abc{
	final int n=10;

	
}
public class FinalDemo {
	public static void main(String args[]) {
		final double PI = 3.14;

		
	}
}
