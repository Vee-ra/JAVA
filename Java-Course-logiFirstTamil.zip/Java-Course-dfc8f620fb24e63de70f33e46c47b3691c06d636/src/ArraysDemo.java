
public class ArraysDemo { //loops

	public static void main(String[] args) {
		
		float oneD[] = new float[50];
		
		char[] c1,c2,c3;
		
		int[][] a = new int[3][4];
	
		
		a[0][0] = 85;
		a[2][3] = 78;
		
		int b[][] = new int[4][];
		
		b[0] = new int[5];
		b[1] = new int[3];
		b[2] = new int[100];
		b[3] = new int[4];
		
		int c[][]  = {
				{2,3,4,5},
				{5,6,4,3},
				{7,8,6,5}
		};
				
		System.out.println(a[2][3]);
	}

}
