/*************************** Arithmetic Operators **************************/
/*************************** Compound Assignment **************************/
/*************************** Increment/Decrement **************************/
public class Operators {

	public static void main(String[] args) {
		
		// + - * / %
		int a = 11,b = 2,c;
		
		//a = a + 1;
		
		c = ++a; //post increment
		//++a; //pre increment
		
		//a--; //post decrement
		//--a; //pre decrement
		
		System.out.println("c is " + c);
		System.out.println("a is " + a);
	}

}
