/*
 * Bitwise operators
 * ~ NOT     << left shift
 * & AND     >> right shift
 * | OR      >>> right shift zero fill
 * ^ EXOR
 */
public class RelationalOperators {
	public static void main(String args[]) {
		
	}
}
