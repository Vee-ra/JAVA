/*
 * Operator Precedence
 * 
 */
public class Operatorsdemo {

	public static void main(String[] args) {
		int a = 5;
		int b = (a ^ 3) ^ 3;
		System.out.println(b);

	}

}
